import { useRef, useState } from 'react'

const facebookUrl = 'https://www.facebook.com/bordsdinakdakan/photos'
const tiktokUrl = 'https://www.tiktok.com/@bordsdinakdakan'
const mapQuery = 'BORDS beside St. Peter’s College of Toril, Toril, Davao City 8000'
const mapUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(mapQuery)}`
const mapEmbedUrl = `https://www.google.com/maps?q=${encodeURIComponent(mapQuery)}&output=embed`
const storyImages = [
  ...Array.from({ length: 4 }, (_, index) => `/images/bords-story-new-${index + 1}.jpg`),
  ...Array.from({ length: 12 }, (_, index) => `/images/story-${String(index + 1).padStart(2, '0')}.jpg`),
]

const dishes: { name: string; label?: string; price?: string; description?: string; image: string }[] = [
  {
    name: 'Dinakdakan Small Tray',
    label: 'FOR SHARING',
    price: '₱750',
    description: 'Authentic Dinakdakan by BORDS. Small tray, good for 8–10 persons.',
    image: '/images/bords-dinak-tray.jpg',
  },
  {
    name: 'Dinakdakan — Walang Mayo',
    label: 'BORDS ORIGINAL',
    description: 'Dinakdakan na walang mayo? Diri rana sa amoa makita.',
    image: '/images/bords-dinak-no-mayo.jpg',
  },
  {
    name: 'Fries N’ Fish',
    label: 'NEW ON THE MENU',
    image: '/images/bords-fries-fish.jpg',
  },
  {
    name: 'Bords Chicken Tenders',
    label: 'PERFECT FOR SHARING',
    price: '₱490',
    description: 'For picnics, camping, birthdays, pulutan, or pasalubong.',
    image: '/images/bords-tenders-sharing.jpg',
  },
  {
    name: 'Bords Chicken Combo',
    price: 'Starts at ₱85',
    image: '/images/bords-chicken-combo.jpg',
  },
  {
    name: 'Birthday Chicken Tenders',
    price: '₱480',
    image: '/images/bords-tenders-birthday.jpg',
  },
  {
    name: 'Pad Kra Pao Bowl',
    price: '₱55',
    description: 'With egg, ₱65.',
    image: '/images/bords-pad-kra-pao.jpg',
  },
  {
    name: 'Dinakdakan ni Bords',
    description: 'Dinakdakan in a bowl with rice, ₱55.',
    image: '/images/bords-dinak-order.jpg',
  },
  {
    name: 'Shawarma Rice',
    image: '/images/bords-shawarma-rice.jpg',
  },
  {
    name: 'Pastil Supreme Bowl',
    description: 'Java rice, pastil, egg, and chicken skin.',
    image: '/images/bords-pastil-supreme.jpg',
  },
  {
    name: 'Fries N’ Chic + Blue Lemonade',
    image: '/images/bords-fries-chic-lemonade.jpg',
  },
  {
    name: 'Hungarian Sausage',
    description: 'Hungarian sausage with fries and rice.',
    image: '/images/bords-hungarian.jpg',
  },
  {
    name: 'Pancit Canton + Chicken Bords',
    description: 'Pancit canton and 10 pieces of Chicken Bords.',
    image: '/images/bords-pancit-chicken.jpg',
  },
  {
    name: 'Rice N’ Chic',
    price: '₱45',
    image: '/images/bords-rice-chic.jpg',
  },
  {
    name: 'Fries N’ Chic',
    price: '₱45',
    image: '/images/bords-fries-chic.jpg',
  },
  {
    name: 'Dinakdakan in a Bowl',
    price: '₱45',
    image: '/images/bords-dinak-bowl.jpg',
  },
  {
    name: 'Magic Combo',
    price: '₱75',
    description: '3 pork BBQ, 2 pastil, and chicken skin.',
    image: '/images/bords-magic-combo.jpg',
  },
  {
    name: 'Pastil X Pork BBQ',
    image: '/images/bords-pastil-bbq.jpg',
  },
  {
    name: 'Chicken Pastil',
    image: '/images/bords-chicken-pastil.jpg',
  },
]

const moreMenuPhotos = [
  ...Array.from({ length: 6 }, (_, index) => `/images/bords-menu-photo-${String(index + 1).padStart(2, '0')}.jpg`),
  ...Array.from({ length: 4 }, (_, index) => `/images/bords-menu-photo-${index + 12}.jpg`),
  '/images/bords-tenders-order.jpg',
  '/images/bords-munchies.jpg',
]

function ArrowIcon({ diagonal = false }: { diagonal?: boolean }) {
  return diagonal ? (
    <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5">
      <path d="M5 19 19 5M7 5h12v12" />
    </svg>
  ) : (
    <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5">
      <path d="M4 12h16m-6-6 6 6-6 6" />
    </svg>
  )
}

function Brand({ small = false }: { small?: boolean }) {
  return (
    <a href="#top" aria-label="BORDS, back to top" className={`brand-logo ${small ? 'brand-logo-small' : ''}`}>
      <img src="/images/bords-logo.jpg" alt="BORDS Dinakdakan ATBP logo" />
    </a>
  )
}

export default function App() {
  const [menuOpen, setMenuOpen] = useState(false)
  const [activePhoto, setActivePhoto] = useState(0)
  const pointerStart = useRef<number | null>(null)

  const changePhoto = (direction: number) => {
    setActivePhoto((current) => (current + direction + storyImages.length) % storyImages.length)
  }

  return (
    <div id="top" className="min-h-screen bg-[#f7f1e7] text-[#2d2019]">
      <div className="announcement-bar">
        <span>GOOD FOOD. GOOD MOOD. ALWAYS BORDS.</span>
        <span className="announcement-star" aria-hidden="true">✳</span>
        <span>GOOD FOOD. GOOD MOOD. ALWAYS BORDS.</span>
      </div>

      <header className="site-header">
        <div className="site-container flex h-[82px] items-center justify-between gap-6 md:h-[94px]">
          <Brand />

          <nav aria-label="Main navigation" className="hidden items-center gap-9 lg:flex">
            <a className="nav-link" href="#menu">The menu</a>
            <a className="nav-link" href="#about">Our story</a>
            <a className="nav-link" href="#contact">Get in touch</a>
          </nav>

          <div className="hidden lg:block">
            <a href="#contact" className="button button-dark">ORDER / INQUIRE <ArrowIcon diagonal /></a>
          </div>

          <button
            type="button"
            aria-label={menuOpen ? 'Close navigation menu' : 'Open navigation menu'}
            aria-expanded={menuOpen}
            aria-controls="mobile-nav"
            onClick={() => setMenuOpen(!menuOpen)}
            className="mobile-toggle lg:hidden"
          >
            <span className={menuOpen ? 'rotate-45 translate-y-[5px]' : ''} />
            <span className={menuOpen ? '-rotate-45 -translate-y-[5px]' : ''} />
          </button>
        </div>
        {menuOpen && (
          <nav id="mobile-nav" aria-label="Mobile navigation" className="mobile-nav lg:hidden">
            <a onClick={() => setMenuOpen(false)} href="#menu">The menu <ArrowIcon diagonal /></a>
            <a onClick={() => setMenuOpen(false)} href="#about">Our story <ArrowIcon diagonal /></a>
            <a onClick={() => setMenuOpen(false)} href="#contact">Get in touch <ArrowIcon diagonal /></a>
            <a onClick={() => setMenuOpen(false)} href="#contact" className="mobile-order">ORDER / INQUIRE <ArrowIcon diagonal /></a>
          </nav>
        )}
      </header>

      <main>
        <section className="hero site-container" aria-labelledby="hero-heading">
          <div className="hero-copy">
            <div className="eyebrow"><span className="eyebrow-line" /> FILIPINO COMFORT FOOD, THE BORDS WAY</div>
            <h1 id="hero-heading" className="hero-title hero-title-menu">DINAKDAKAN <span className="hero-divider">|</span><br /><span>BORDS CHICKEN<br />AND TENDERS</span> <span className="hero-divider">|</span><br />PASTIL</h1>
            <p className="hero-subtitle">Big flavor, zero fuss.</p>
            <p className="hero-description">From punchy dinakdakan to crispy chicken and comforting pastil — there’s always something good cooking at BORDS.</p>
            <div className="hero-actions">
              <a href="#menu" className="button button-orange">EXPLORE THE MENU <ArrowIcon diagonal /></a>
              <a href="#about" className="text-link">Get to know us <ArrowIcon /></a>
            </div>
            <div className="hero-footnote"><span className="footnote-spark">✳</span> MADE FOR THE LOVE OF GOOD FOOD</div>
          </div>

          <div className="hero-visual">
            <div className="hero-image-frame">
              <img src="/images/hero-bords.jpg" alt="BORDS pastil and loaded chicken-and-fries bowls" className="hero-image" />
            </div>
            <div className="hero-stamp" aria-label="Always made to satisfy">
              <span className="stamp-top">ALWAYS MADE</span>
              <span className="stamp-spark" aria-hidden="true">✳</span>
              <span className="stamp-bottom">TO SATISFY</span>
            </div>
            <div className="hero-image-caption"><span>01 / 03</span><span>GOOD FOOD LIVES HERE</span></div>
          </div>
        </section>

        <div className="ticker" aria-hidden="true">
          <div className="ticker-inner">
            {Array.from({ length: 4 }, (_, index) => <span key={index}>MADE WITH FLAVOR <b>✳</b> SERVED WITH HEART <b>✳</b> </span>)}
          </div>
        </div>

        <section id="menu" className="menu-section site-container" aria-labelledby="menu-heading">
          <div className="section-heading-row">
            <div>
              <p className="section-kicker"><span>01</span> / WHAT WE DO BEST</p>
              <h2 id="menu-heading" className="section-title">THE GOOD <em>STUFF.</em></h2>
            </div>
            <p className="section-intro">From sharing trays to quick bites — see what’s cooking at BORDS.</p>
          </div>

          <div className="menu-grid">
            {dishes.map((dish, index) => (
              <article className="dish-card" key={dish.name}>
                <div className="dish-image-wrap">
                  <img src={dish.image} alt={dish.name} loading="lazy" />
                  <span className="dish-number">{String(index + 1).padStart(2, '0')} / {String(dishes.length).padStart(2, '0')}</span>
                </div>
                <div className="dish-content">
                  {dish.label && <p className="dish-label">{dish.label}</p>}
                  <h3>{dish.name}</h3>
                  {dish.price && <p className="dish-price">{dish.price}</p>}
                  {dish.description && <p className="dish-description">{dish.description}</p>}
                  <a href="#contact" aria-label={`Ask about ${dish.name}`} className="dish-link">ASK ABOUT THIS <ArrowIcon diagonal /></a>
                </div>
              </article>
            ))}
          </div>
          <div className="more-menu-heading">
            <p className="section-kicker"><span>MORE</span> / FROM THE BORDS KITCHEN</p>
            <h3>MORE TO <em>CRAVE.</em></h3>
          </div>
          <div className="more-menu-grid">
            {moreMenuPhotos.map((image, index) => (
              <img key={image} src={image} alt={`BORDS menu photo ${index + 1}`} loading="lazy" />
            ))}
          </div>
        </section>

        <section id="about" className="about-section" aria-labelledby="about-heading">
          <div className="site-container about-grid">
            <div className="story-gallery" aria-label="BORDS photo album">
              <div
                className="about-image-wrap"
                onPointerDown={(event) => { if (event.button === 0) pointerStart.current = event.clientX }}
                onPointerUp={(event) => {
                  if (pointerStart.current === null) return
                  const distance = event.clientX - pointerStart.current
                  pointerStart.current = null
                  if (Math.abs(distance) > 55) changePhoto(distance < 0 ? 1 : -1)
                }}
                onPointerCancel={() => { pointerStart.current = null }}
              >
                <img key={activePhoto} src={storyImages[activePhoto]} alt={`BORDS photo album image ${activePhoto + 1} of ${storyImages.length}`} loading="lazy" draggable="false" />
                <div className="about-image-tag">A LITTLE BIT OF EVERYTHING.<br />A WHOLE LOT OF FLAVOR.</div>
              </div>
              <div className="gallery-controls">
                <span aria-live="polite">BORDS MOMENTS <strong>{String(activePhoto + 1).padStart(2, '0')} / {String(storyImages.length).padStart(2, '0')}</strong></span>
                <div className="gallery-buttons">
                  <button type="button" onClick={() => changePhoto(-1)} aria-label="Previous album photo">←</button>
                  <button type="button" onClick={() => changePhoto(1)} aria-label="Next album photo">→</button>
                </div>
              </div>
            </div>
            <div className="about-copy">
              <p className="section-kicker light-kicker"><span>02</span> / THE BORDS SPIRIT</p>
              <h2 id="about-heading" className="about-title">GOOD FOOD<br />BRINGS US <em>TOGETHER.</em></h2>
              <p><strong>Main specialty:</strong> Dinakdakan, a Filipino dish commonly made with pork and seasoned with ingredients such as onions, vinegar/calamansi, and other seasonings.</p>
              <p><strong>Target customers:</strong> Students, nearby residents, workers, and people looking for affordable local food.</p>
              <p><strong>Business setting:</strong> Appears to be a small/local food establishment rather than a large chain.</p>
              <p>Whether you’re in the mood for dinakdakan, chicken and tenders, or pastil, come hungry. We’ve got something for that craving.</p>
              <a href="#contact" className="button button-outline">LET’S TALK FOOD <ArrowIcon diagonal /></a>
            </div>
          </div>
        </section>

        <section id="contact" className="contact-section site-container" aria-labelledby="contact-heading">
          <p className="section-kicker"><span>03</span> / YOUR NEXT CRAVING STARTS HERE</p>
          <div className="contact-content">
            <h2 id="contact-heading">HUNGRY<br /><em>YET?</em></h2>
            <div className="contact-right">
              <p>Good choice. Reach out to BORDS to ask about the menu, availability, and how to get your favorites.</p>
              <div className="social-actions">
                <a href={facebookUrl} target="_blank" rel="noopener noreferrer" className="button button-orange">FIND US ON FACEBOOK <ArrowIcon diagonal /></a>
                <a href={tiktokUrl} target="_blank" rel="noopener noreferrer" className="button button-social">FOLLOW ON TIKTOK <ArrowIcon diagonal /></a>
              </div>
            </div>
          </div>
          <div className="location-panel">
            <div className="location-details">
              <p className="section-kicker"><span>FIND US</span> / TORIL, DAVAO CITY</p>
              <h3>COME ON <em>OVER.</em></h3>
              <p><strong>Area</strong>Toril, Davao City, Davao del Sur</p>
              <p><strong>Landmark</strong>Beside or near St. Peter’s College of Toril</p>
              <p><strong>Business type</strong>Local food and dining establishment</p>
              <a href={mapUrl} target="_blank" rel="noopener noreferrer" className="location-link">OPEN IN GOOGLE MAPS <ArrowIcon diagonal /></a>
            </div>
            <iframe title="Map showing BORDS near St. Peter’s College of Toril" src={mapEmbedUrl} loading="lazy" referrerPolicy="no-referrer-when-downgrade" allowFullScreen />
          </div>
          <div className="contact-bottom"><span>GOOD FOOD IS WORTH SHARING.</span><span aria-hidden="true">✳</span></div>
        </section>
      </main>

      <footer className="footer">
        <div className="site-container footer-inner">
          <div><Brand small /><p>Dinakdakan. Chicken & Tenders. Pastil.<br />Made for every craving.</p></div>
          <div className="footer-links"><a href="#menu">MENU</a><a href="#about">ABOUT</a><a href="#contact">CONTACT</a><a href="#top">BACK TO TOP ↑</a></div>
          <p className="copyright">© {new Date().getFullYear()} BORDS. GOOD FOOD, GOOD MOOD.</p>
        </div>
      </footer>
    </div>
  )
}
